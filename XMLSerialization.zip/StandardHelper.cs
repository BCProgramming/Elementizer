﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Imaging;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Security;
using System.Text;
using System.Xml.Linq;

namespace BASeCamp.XMLSerialization
{
    public class StandardHelper : IXmlSerializationProvider<Point>, IXmlSerializationProvider<PointF>, 
        IXmlSerializationProvider<Rectangle>, IXmlSerializationProvider<RectangleF>,
        IXmlSerializationProvider<Image>,IXmlSerializationProvider<System.Int16>,IXmlSerializationProvider<System.Int32>,IXmlSerializationProvider<System.Int64>
        ,IXmlSerializationProvider<String>,IXmlSerializationProvider<System.Single>,IXmlSerializationProvider<System.Double>,IXmlSerializationProvider<System.Decimal>,IXmlSerializationProvider<System.Boolean>
    {
        public static StandardHelper Static = new StandardHelper();

#region generic helpers
        
        private static Dictionary<Type, object> SerializationHelpers = new Dictionary<Type, object>() {
            {typeof(Image),Static},
            {typeof(Rectangle),Static},
            {typeof(RectangleF),Static},
            {typeof(Point),Static},
            {typeof(PointF),Static},
            {typeof(Int16),Static},
            {typeof(Int32),Static},
            {typeof(Int64),Static},
            {typeof(Single),Static},
            {typeof(Double),Static},
            {typeof(Decimal),Static},
            {typeof(String),Static}
        };


        public static void AddHelper<T>(IXmlSerializationProvider<T> Provider)
        {

            if (SerializationHelpers.ContainsKey(typeof(T)))
            {
                SerializationHelpers.Remove(typeof(T));
            }
            SerializationHelpers.Add(typeof(T), Provider);
        }
        public static IXmlSerializationProvider<T> GetHelper<T>()
        {
            Type gettype = typeof(T);
            foreach (Type iterate in SerializationHelpers.Keys)
            {
                if (iterate.IsInterface)
                {
                    foreach (Type checkinterface in gettype.GetInterfaces())
                    {
                        if (checkinterface.Equals(gettype))
                            return (IXmlSerializationProvider<T>)SerializationHelpers[iterate];
                    }
                }

                if (iterate.Equals(gettype) || iterate.IsSubclassOf(gettype))
                    return (IXmlSerializationProvider<T>)SerializationHelpers[iterate];


            }
            return null;
        }
        public static XElement SaveList<T>(List<T> SourceData,String pNodeName)
        {
            //without a Func as in the overload, we'll try to "build" our own function.
            //the function we build will close over a instance of IXMLSerializationProvider (or the type GetXMLData method if it implements IXMLSerializable).
            //basically we want to create the function to handle the loading of classes that implement the interface or have a defined provider.
            
            Func<T, XElement> buildfunc = (elem) => SaveElement(elem,pNodeName);
            
            return SaveList<T>(buildfunc, pNodeName, SourceData);

        }
        public static List<T> LoadList<T>(XElement Source)
        {
            Func<XElement, T> constructitem = (xdata) => LoadElement<T>(xdata);
            return LoadList<T>(constructitem, Source);
        }
        public static XElement SaveElement<T>(T SourceData,String pNodeName)
        {
            bool implementsInterface = false;
            Func<T, XElement> buildfunc = null;
            foreach (var searchinterface in typeof(T).GetInterfaces())
            {
                if (searchinterface.Equals(typeof(IXMLSerializable)))
                {
                    implementsInterface = true;
                }
            }
            if (implementsInterface)
            {
                //if it implements the interface, we'll use the GetXMLData.
                buildfunc = (elem) => ((IXMLSerializable)elem).GetXmlData(pNodeName);
            }
            else
            {
                //otherwise, let's see if there is an XMLProvider we can use.
                var retrievehelper = GetHelper<T>();
                if (retrievehelper == null)
                {
                    throw new ArgumentException("Provided type " + typeof(T).Name + " Does not implement IXMLSerializable and does not have a IXMLProvider implementation available.");
                }
                else
                {
                    buildfunc = (elem) => retrievehelper.SerializeObject(elem, pNodeName);
                }
            }
            if (buildfunc == null)
            {
                return null;
            }
            return buildfunc(SourceData);
        }
        public static T LoadElement<T>(XElement XMLSource)
        {
            Func<XElement, T> constructitem = null;
            bool implementsInterface = false;
            foreach (var searchinterface in typeof(T).GetInterfaces())
            {
                if (searchinterface.Equals(typeof(IXMLSerializable)))
                {
                    implementsInterface = true;
                }
            }
            if (implementsInterface)
            {
                //if it implements the interface, we'll use the constructor..
                constructitem = (xdata) =>
                    {
                        ConstructorInfo ci = typeof(T).GetConstructor(new Type[] { typeof(XElement) });
                        if (ci == null) return default(T);
                        return (T)ci.Invoke(new object[] { xdata });
                    };
            }
            else
            {
                //otherwise, let's see if there is an XMLProvider we can use.
                var retrievehelper = GetHelper<T>();
                if (retrievehelper == null)
                {
                    throw new ArgumentException("Provided type " + typeof(T).Name + " Does not implement IXMLSerializable and does not have a IXMLProvider implementation available.");
                }
                else
                {
                    constructitem = (xdata) => retrievehelper.DeSerializeObject(xdata);
                    
                }
            }
            return constructitem(XMLSource);
        }
        /// <summary>
        /// Saves a list to an XElement.
        /// </summary>
        /// <typeparam name="T">Type of the list to save.</typeparam>
        /// <param name="SourceTransform">Function that takes the Type T item and saves it to an XElement.</param>
        /// <param name="SourceData">Source List data.</param>
        /// <returns></returns>
        public static XElement SaveList<T>(Func<T, XElement> SourceTransform,String pNodeName, List<T> SourceData)
        {
            XElement ListNode = new XElement
                (pNodeName,
                    new XAttribute("ListType", typeof(T).Name));
            foreach (T iterateNode in SourceData)
            {
                XElement addContent = SourceTransform(iterateNode);
                ListNode.Add(addContent);
            }
            return ListNode;
        }

        public static List<T> LoadList<T>(Func<XElement, T> ListLoader, XElement Source)
        {
            List<T> resultlist = new List<T>();
            foreach (XElement child in Source.DescendantNodes())
            {
                T resultnode = ListLoader(child);
                resultlist.Add(resultnode);
            }
            return resultlist;
        }

        #endregion
        
        #region Point Serialization

        XElement IXmlSerializationProvider<Point>.SerializeObject(Point sourceItem,String pNodeName)
        {
            if (pNodeName == null) pNodeName = "Point";
            return new XElement(pNodeName, new XAttribute("X", sourceItem.X), new XAttribute("Y", sourceItem.Y));
        }

        XElement IXmlSerializationProvider<PointF>.SerializeObject(PointF sourceItem,String pNodeName)
        {
            if (pNodeName == null) pNodeName = "PointF";
            return new XElement(pNodeName, new XAttribute("X", sourceItem.X), new XAttribute("Y", sourceItem.Y));
        }

        #endregion

        #region PointF Serialization

        XElement IXmlSerializationProvider<short>.SerializeObject(short sourceItem, string pNodeName)
        {
            return new XElement(pNodeName,new XAttribute("Value",sourceItem));
        }

        XElement IXmlSerializationProvider<int>.SerializeObject(int sourceItem, string pNodeName)
        {
            return new XElement(pNodeName, new XAttribute("Value", sourceItem));
        }

        XElement IXmlSerializationProvider<long>.SerializeObject(long sourceItem, string pNodeName)
        {
            return new XElement(pNodeName, new XAttribute("Value", sourceItem));
        }

        XElement IXmlSerializationProvider<string>.SerializeObject(string sourceItem, string pNodeName)
        {
            return new XElement(pNodeName, new XAttribute("Value", sourceItem));
        }

        XElement IXmlSerializationProvider<float>.SerializeObject(float sourceItem, string pNodeName)
        {
            return new XElement(pNodeName, new XAttribute("Value", sourceItem));
        }

        XElement IXmlSerializationProvider<double>.SerializeObject(double sourceItem, string pNodeName)
        {
            return new XElement(pNodeName, new XAttribute("Value", sourceItem));
        }

        XElement IXmlSerializationProvider<decimal>.SerializeObject(decimal sourceItem, string pNodeName)
        {
            return new XElement(pNodeName, new XAttribute("Value", sourceItem));
        }

        XElement IXmlSerializationProvider<bool>.SerializeObject(bool sourceItem, string pNodeName)
        {
            return new XElement(pNodeName, new XAttribute("Value", sourceItem));
        }

        bool IXmlSerializationProvider<bool>.DeSerializeObject(XElement xmlData)
        {
            return bool.Parse(xmlData.Attribute("Value").Value);
        }
        decimal IXmlSerializationProvider<decimal>.DeSerializeObject(XElement xmlData)
        {
            return decimal.Parse(xmlData.Attribute("Value").Value);
        }

        double IXmlSerializationProvider<double>.DeSerializeObject(XElement xmlData)
        {
            return double.Parse(xmlData.Attribute("Value").Value);
        }

        float IXmlSerializationProvider<float>.DeSerializeObject(XElement xmlData)
        {
            return float.Parse(xmlData.Attribute("Value").Value);
        }

        string IXmlSerializationProvider<string>.DeSerializeObject(XElement xmlData)
        {
            return xmlData.Attribute("Value").Value;
        }

        long IXmlSerializationProvider<long>.DeSerializeObject(XElement xmlData)
        {
            return long.Parse(xmlData.Attribute("Value").Value);
        }

        int IXmlSerializationProvider<int>.DeSerializeObject(XElement xmlData)
        {
            throw new NotImplementedException();
        }

        short IXmlSerializationProvider<short>.DeSerializeObject(XElement xmlData)
        {
            throw new NotImplementedException();
        }

        PointF IXmlSerializationProvider<PointF>.DeSerializeObject(XElement xmlData)
        {
            float X = 0, Y = 0;
            String sX, sY;
            sX = sY = "0";
            foreach (XAttribute LookAttribute in xmlData.Attributes())
            {
                if (LookAttribute.Name == "X")
                    sX = LookAttribute.Value;
                else if (LookAttribute.Name == "Y")
                    sY = LookAttribute.Value;
            }
            X = Single.Parse(sX);
            Y = Single.Parse(sY);
            return new PointF(X, Y);
        }


        Point IXmlSerializationProvider<Point>.DeSerializeObject(XElement xmlData)
        {
            int X = 0, Y = 0;
            String sX, sY;
            sX = sY = "0";
            foreach (XAttribute LookAttribute in xmlData.Attributes())
            {
                if (LookAttribute.Name == "X")
                    sX = LookAttribute.Value;
                else if (LookAttribute.Name == "Y")
                    sY = LookAttribute.Value;
            }
            X = Int32.Parse(sX);
            Y = Int32.Parse(sY);
            return new Point(X, Y);
        }

        #endregion

        #region Rectangle Serialization

        XElement IXmlSerializationProvider<Rectangle>.SerializeObject(Rectangle sourceItem,String pNodeName)
        {
            if (pNodeName == null) pNodeName = "Rectangle";
            return new XElement
                ("Rectangle",
                    new XAttribute("Left", sourceItem.Left), new XAttribute("Top", sourceItem.Top), new XAttribute("Width", sourceItem.Width),
                    new XAttribute("Height", sourceItem.Height));
        }

        Rectangle IXmlSerializationProvider<Rectangle>.DeSerializeObject(XElement xmlData)
        {
            int Left = 0, Top = 0, Width = 0, Height = 0;
            String sLeft, sTop, sWidth, sHeight;
            sLeft = sTop = sWidth = sHeight = "0";
            foreach (XAttribute LookAttribute in xmlData.Attributes())
            {
                if (LookAttribute.Name == "Left")
                    sLeft = LookAttribute.Value;
                else if (LookAttribute.Name == "Top")
                    sTop = LookAttribute.Value;
                else if (LookAttribute.Name == "Width")
                    sWidth = LookAttribute.Value;
                else if (LookAttribute.Name == "Height")
                    sHeight = LookAttribute.Value;
            }
            Left = Int32.Parse(sLeft);
            Top = Int32.Parse(sTop);
            Width = Int32.Parse(sWidth);
            Height = Int32.Parse(sHeight);
            return new Rectangle(Left, Top, Width, Height);
        }

        #endregion

        #region RectangleF deserialization

        XElement IXmlSerializationProvider<RectangleF>.SerializeObject(RectangleF sourceItem,String pNodeName)
        {
            if (pNodeName == null) pNodeName = "Rectangle";
            return new XElement
                ("Rectangle",
                    new XAttribute("Left", sourceItem.Left), new XAttribute("Top", sourceItem.Top), new XAttribute("Width", sourceItem.Width),
                    new XAttribute("Height", sourceItem.Height));
        }

        RectangleF IXmlSerializationProvider<RectangleF>.DeSerializeObject(XElement xmlData)
        {
            float Left = 0, Top = 0, Width = 0, Height = 0;
            String sLeft, sTop, sWidth, sHeight;
            sLeft = sTop = sWidth = sHeight = "0";
            foreach (XAttribute LookAttribute in xmlData.Attributes())
            {
                if (LookAttribute.Name == "Left")
                    sLeft = LookAttribute.Value;
                else if (LookAttribute.Name == "Top")
                    sTop = LookAttribute.Value;
                else if (LookAttribute.Name == "Width")
                    sWidth = LookAttribute.Value;
                else if (LookAttribute.Name == "Height")
                    sHeight = LookAttribute.Value;
            }
            Left = Single.Parse(sLeft);
            Top = Single.Parse(sTop);
            Width = Single.Parse(sWidth);
            Height = Single.Parse(sHeight);
            return new RectangleF(Left, Top, Width, Height);
        }

        #endregion

        #region Image implementation

        XElement IXmlSerializationProvider<Image>.SerializeObject(Image sourceItem,String pNodeName)
        {
            if (pNodeName == null) pNodeName = "Image";
            //an image. we'll do a bit of a cheat here, and base64 encode the image data as the value of the XML tag.
            //Convert.ToBase64String(SourceItem.)
            //to get the bytes, we'll save the image to a MemoryStream.
            String sBase64 = null;
            using (MemoryStream ms = new MemoryStream())
            {
                sourceItem.Save(ms, ImageFormat.Png);
                byte[] buff = ms.GetBuffer();
                sBase64 = Convert.ToBase64String(buff);
            }
            return new XElement("Image", sBase64);
        }

        Image IXmlSerializationProvider<Image>.DeSerializeObject(XElement xmlData)
        {
            String sBase64 = xmlData.Value;
            byte[] contents = Convert.FromBase64String(sBase64);
            Image result = null;
            using (MemoryStream ms = new MemoryStream())
            {
                ms.Write(contents, 0, contents.Length);
                ms.Seek(0, SeekOrigin.Begin);
                result = Image.FromStream(ms);
            }
            return result;
        }

        #endregion
    }

  
}